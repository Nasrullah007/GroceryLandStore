

export const environment = {
  UsersAPIURL: 'https://qa.groceryland.pk/',
  production: false
};
